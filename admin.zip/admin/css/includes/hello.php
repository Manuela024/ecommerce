<?php
echo "Hello TechShop !";